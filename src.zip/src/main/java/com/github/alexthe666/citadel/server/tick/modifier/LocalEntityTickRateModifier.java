package com.github.alexthe666.citadel.server.tick.modifier;

import com.github.alexthe666.citadel.server.entity.IModifiesTime;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class LocalEntityTickRateModifier extends LocalTickRateModifier {

    private int entityId;
    private EntityType expectedEntityType;
    private boolean isEntityValid = true;

    public LocalEntityTickRateModifier(int entityId, EntityType expectedEntityType, double range, ResourceKey<Level> dimension, int durationInMasterTicks, float tickRateMultiplier) {
        super(TickRateModifierType.LOCAL_ENTITY, range, dimension, durationInMasterTicks, tickRateMultiplier);
        this.entityId = entityId;
        this.expectedEntityType = expectedEntityType;
    }

    public LocalEntityTickRateModifier(CompoundTag tag) {
        super(tag);
        this.entityId = tag.getIntOr("EntityId", -1);
        this.expectedEntityType = BuiltInRegistries.ENTITY_TYPE.getValue(Identifier.parse(tag.getStringOr("EntityType", BuiltInRegistries.ENTITY_TYPE.getKey(EntityType.PIG).toString())));
    }

    @Override
    public Vec3 getCenter(Level level) {
        Entity entity = level.getEntity(this.entityId);
        if(isEntityValid(level) && entity != null){
            return entity.position();
        }
        return Vec3.ZERO;
    }

    @Override
    public boolean appliesTo(Level level, double x, double y, double z) {
        return super.appliesTo(level, x, y, z) && isEntityValid(level);
    }

    public boolean isEntityValid(Level level){
        Entity entity = level.getEntity(this.entityId);
        return entity != null && entity.isAddedToLevel() && entity.getType().equals(expectedEntityType) && entity.isAlive() && (!(entity instanceof IModifiesTime) || ((IModifiesTime)entity).isTimeModificationValid(this));
    }

    @Override
    public CompoundTag toTag() {
        CompoundTag tag = super.toTag();
        tag.putInt("EntityId", entityId);
        Identifier entityTypeId = BuiltInRegistries.ENTITY_TYPE.getKey(this.expectedEntityType);
        tag.putString("EntityType", entityTypeId.toString());
        return tag;
    }

    public int getEntityId() {
        return entityId;
    }

    public void setEntityId(int entityId) {
        this.entityId = entityId;
    }

    public EntityType getExpectedEntityType() {
        return expectedEntityType;
    }

    public void setExpectedEntityType(EntityType expectedEntityType) {
        this.expectedEntityType = expectedEntityType;
    }
}
